# Task 12 – Re-evaluate and Adapt the Design

## Objective
Re-evaluate the original fare design after adding Airport Zone 4, a weekend discount, and monthly passes.

## Changed Requirements
- Airport Zone 4 has a base fare of ₹60.
- A 10% weekend discount applies.
- The weekend discount must not combine with the peak surcharge.
- A monthly pass allows unlimited journeys in two selected zones.

## Impact Analysis
The zone enumeration and fare values must be updated. The original switch-based fare logic must support the fourth zone or be replaced by a fare table. Discount logic must distinguish weekend journeys from weekday peak journeys. The SmartCard class must support pass eligibility, and a Pass class can represent the two selected zones and pass status.

## Design Decision
Modify the original design. Retain the SmartCard abstraction, replace fixed fare selection with a fare table, separate discount logic, and introduce a Pass class.

## Worked Examples
Assuming the original 20% peak surcharge remains:
- Zone 1, weekday off-peak: ₹10.00
- Zone 2, weekday peak: ₹24.00
- Airport, weekday peak: ₹72.00
- Airport, weekend: ₹54.00
- A covered journey under a valid pass: ₹0.00 fare

The weekend rule takes priority, so the peak surcharge is not added on weekends.

## Testing and Evidence
Include actual output screenshots for normal fares, weekday peak fares, Airport Zone 4, weekend discount, and pass-covered journeys. Record expected and actual results in the assignment report.

## Limitations
A demonstration using a Boolean pass-active flag does not implement actual monthly expiry dates, pass purchase, or renewal. Additional validation and integration testing are required before production use.

## Conclusion
The modified design is easier to extend and separates fare selection, discounts, pass eligibility, and card balance management. The final decision should be defended using the test results from the revised implementation.
