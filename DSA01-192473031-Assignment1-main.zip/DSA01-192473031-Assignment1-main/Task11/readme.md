# Task 11 – Recommend and Defend the Final Design

## Objective
Recommend a maintainable design for the metro fare system based on experimental evidence.

## Recommendation
Use integer paise for money, named constants for fare rules, a `SmartCard` class for balance management, and a separate fare-calculation component. Use a suitable large integer type such as `long long` for accumulated totals.

## Fare Revisions
Compiled-in fare values require source-code changes, recompilation, testing, and redeployment. Alternatively, a validated configuration file can be read when the gate starts.

## Configuration File Complexity
Reading and validating z fare values takes O(z) time and O(z) space to store the table. The runtime cost is incurred at startup, while configuration files can reduce the maintenance effort associated with repeated recompilation and deployment.

## Limitations
A simple zone-based design may not fully support concessions, transfers, distance-based pricing, or other complex fare policies. Those features require clearly defined rules and additional tests.

## Whole-Network Correctness
Earlier tests support the tested cases, including fare boundaries, low balance, invalid zones, and accumulated totals. They do not prove correctness for every possible network condition. Additional integration and boundary testing is required.

## Evidence
Use the actual results from Tasks 9 and 10 to justify the recommendation. Include the complete evaluation and complexity analysis in the assignment report.
